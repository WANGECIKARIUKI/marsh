import React from 'react';

function Whatsapp(){

    return(
        <div>
            Activate your Account to View
        </div>
    )
}

export default Whatsapp;