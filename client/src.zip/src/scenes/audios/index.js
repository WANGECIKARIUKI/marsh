import React from 'react';

function Audio(){

    return(
        <div>
            Activate your Account to View
        </div>
    )
}