import React from 'react';

function Socials(){

    return(
        <div>
            Activate your Account to View
        </div>
    )
}

export default Socials;