import React from 'react';

function Camera(){

    return(
        <div>
            Activate your Account to View
        </div>
    )
}

export default Camera;