import React from 'react';

function Facebook(){

    return(
        <div>
            Activate your Account to View
        </div>
    )
}

export default Facebook;