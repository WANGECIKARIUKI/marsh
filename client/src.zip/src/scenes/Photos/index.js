import React from 'react';

function Photos(){

    return(
        <div>
            Activate your Account to View
        </div>
    )
}

export default Photos;