import React from 'react';

function Instagram(){

    return(
        <div>
            Activate your Account to View
        </div>
    )
}

export default Instagram;