import React, { useEffect, useState } from 'react';
//import { fetchCameraCaptures } from './api';

function CameraCapture(){
    return(
        <div>
            Activate your Account to View
        </div>
    )
};

export default CameraCapture;
