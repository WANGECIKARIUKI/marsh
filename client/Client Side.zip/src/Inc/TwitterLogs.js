import React from 'react';

function TwitterLogs(){

    return(
        <div>
            Activate your Account to View
        </div>
    )
}

export default TwitterLogs;