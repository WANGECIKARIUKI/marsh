import React from 'react';

function SnapchatLogs(){

    return(
        <div>
            Activate your Account to View
        </div>
    )
}

export default SnapchatLogs;