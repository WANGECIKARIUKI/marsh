import React from 'react';

function ScreenrecordingLogs(){

    return(
        <div>
            Activate your Account to View
        </div>
    )
}

export default ScreenrecordingLogs;