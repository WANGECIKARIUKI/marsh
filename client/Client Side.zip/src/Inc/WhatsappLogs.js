import React from 'react';

function WhatsappLogs(){

    return(
        <div>
            Activate your Account to View
        </div>
    )
}

export default WhatsappLogs;