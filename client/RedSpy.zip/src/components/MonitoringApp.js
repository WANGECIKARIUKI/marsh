import React from 'react';


function MonitoringApp(){

    return (
        <div></div>
    )
}

export default MonitoringApp;